package com.myappcompany.rajan.ucheck;

public class ImageData {

    private String imgurl;

    public ImageData(String str) {
        this.imgurl = str;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public String getImgurl() {
        return imgurl;
    }
}
